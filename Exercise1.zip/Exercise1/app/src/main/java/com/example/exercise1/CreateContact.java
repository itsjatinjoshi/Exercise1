package com.example.exercise1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class CreateContact extends AppCompatActivity  implements View.OnClickListener {
    EditText etName, etNum, etWeb, etLoc;
    ImageView ivSad, ivHappy, ivNormal;

    @Override
    public void onClick(View v) {

        if (etName.getText().toString().isEmpty() || etNum.getText().toString().isEmpty() ||
                etWeb.getText().toString().isEmpty() || etLoc.getText().toString().isEmpty())
        {
            Toast.makeText(this, "Please enter all fields", Toast.LENGTH_SHORT).show();
        }
        else
            {
            Intent intent = new Intent();
            intent.putExtra("name", etName.getText().toString().trim());
            intent.putExtra("num", etNum.getText().toString().trim());
            intent.putExtra("web", etWeb.getText().toString().trim());
            intent.putExtra("map", etLoc.getText().toString().trim());

            if(v.getId() == R.id.ivHappy){
                intent.putExtra("mood", "happy");
            }
            else if(v.getId() == R.id.ivNormal){
                intent.putExtra("mood", "normal");
            }
            else
            {
                intent.putExtra("mood", "sad");
            }
            setResult(RESULT_OK,intent);
            CreateContact.this.finish();
        }
     }
        @Override
        protected void onCreate (Bundle savedInstanceState){
            super.onCreate(savedInstanceState);
            setContentView(R.layout.create_contact);

            etName = findViewById(R.id.etName);
            etNum = findViewById(R.id.etNum);
            etWeb = findViewById(R.id.etWeb);
            etLoc = findViewById(R.id.etLoc);

            ivSad = findViewById(R.id.ivSad);
            ivHappy = findViewById(R.id.ivHappy);
            ivNormal = findViewById(R.id.ivNormal);

            ivSad.setOnClickListener(this);
            ivHappy.setOnClickListener(this);
            ivNormal.setOnClickListener(this);


        }



                }